-module(un2).
%% coding: latin-1

-export([t/0]).

%% @doc F�pp
t() ->
    �rlig.
